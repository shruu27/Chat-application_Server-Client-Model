import socket as sk
import threading as td
import pickle as pc
import time
import Encrypt
import Database

Database.create_database("chat")

host = "127.0.0.1"     # Enter current IP address
port = 8081

server = sk.socket(sk.AF_INET, sk.SOCK_STREAM)
server.bind((host,port))

server.listen()
clients = []
aliases = []
address = []
buttons_list = []
connected_clients = []

count = 0

def send(message, source, dest, rec, img):
    if dest not in clients:
        print("Destination not found")
        return
    time_recieve = time.strftime("%H:%M",time.localtime())
    data = (message,source,time_recieve,img)
    out = pc.dumps(data)
    dest.send(out)
    Database.insert_message(rec, source, 0, message, time_recieve,img)

def handle(client):
    global count
    while True:
        try :
            # got_from_client = client.recv(102400)
            got_from_client = client.recv(10 * 1024 * 1024)
        except:
            index = clients.index(client)
            clients.remove(client)
            client.close()
            alias = aliases[index]
            print("[SERVER] ",alias," ",address[index]," has disconnected from the server [",time.strftime("%H:%M",time.localtime()),"]",sep="")
            count-=1
            print("Active Connections :",count,end="\n\n")
            aliases.pop(index)
            address.pop(index)
            break
        got_from_client = pc.loads(got_from_client)
        print(got_from_client)
        message = got_from_client[0]
        sender = aliases[clients.index(client)]
        rec = got_from_client[1]
        reciever = ""
        img=got_from_client[3]
        try:
            reciever = clients[aliases.index(rec)]
        except:
            print("[SERVER] ERROR : The reciver of the message was not found")
            print("                ",sender," please recheck your recipient...\n")
            continue
        time_sent = got_from_client[2]
        #print(str(time))

        # Database operations
        Database.insert_message(sender, rec, 1, message, time_sent,img)

        #print(aliases, address)
        send(message, sender, reciever, rec, img)

def notify_clients(client_name):
    global clients
    global aliases

    for client_socket in clients:
        try:
            # Construct a message with information about all connected clients
            active_users = ', '.join(aliases)
            print(aliases)
            message = f"{client_name} has joined the chat. Active users: {active_users}"

            data = (message, "SERVER", time.strftime("%H:%M", time.localtime()))
            out = pc.dumps(data)
            client_socket.send(out)

            alias_data = ("ALIAS_LIST", aliases)
            alias_out = pc.dumps(alias_data)
            client_socket.send(alias_out)
        except:
            continue

def Server():
    global count
    print("The server is running...\n")
    while True:
        client, adr = server.accept()
        client.send(pc.dumps(("Please send us your name to load data : ",)))
        alias = client.recv(1024).decode()

        # Database Operations and reloading state
        Database.create_user_table(alias)
        msg_history = Database.load_data(alias)
        if msg_history != 0:
            msg_history = pc.dumps(msg_history)
            client.send(msg_history)

        aliases.append(alias)
        clients.append(client)
        address.append(adr)

        # Notify existing clients about the new client
        notify_clients(alias)

        print("[SERVER] ", alias, " ", adr, " has connected to the server [", time.strftime("%H:%M", time.localtime()), "]", sep="")
        count += 1
        print("Active Connections :", count, end="\n\n")
        thread = td.Thread(target=handle, args=(client,))
        thread.start()

if __name__ == "__main__":
    Server()

""" notifies in cmd prompt for existing clients"""
"""to do: notify new users about existing clients, button for client"""
""" creates tab"""
""" for file5"""

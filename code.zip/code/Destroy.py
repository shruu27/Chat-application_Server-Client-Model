import Database

Database.destroy_database("chat")
